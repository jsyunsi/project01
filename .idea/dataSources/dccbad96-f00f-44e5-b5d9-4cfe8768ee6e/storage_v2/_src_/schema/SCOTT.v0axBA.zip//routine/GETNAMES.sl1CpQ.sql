CREATE function getnames(v_deptno dept.deptno%type) return varchar2
 is
   v_result varchar2(3000);
   cursor emp_cur is select * from emp where deptno=v_deptno;
   emp_row emp_cur%rowtype;
   begin
   open emp_cur;
   loop
   fetch emp_cur into emp_row;
   exit when emp_cur%notfound;
   --dbms_output.put_line(emp_row.ename);
   v_result:=nvl(v_result,'')||','||emp_row.ename;
   end loop;
   close emp_cur;
	if(length(v_result)>0) then
		v_result:=substr(v_result,2);
	end if;
   return v_result;
end;
/

